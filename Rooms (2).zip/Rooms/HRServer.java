import java.rmi.Naming;

// Η κλάση HRServer υλοποιεί τον RMI (Remote Method Invocation) server για το σύστημα διαχείρισης δωματίων ξενοδοχείου.
public class HRServer{
    // Κατασκευαστής της κλάσης HRServer.
    public HRServer(){
        try{
             // Δημιουργούμε ένα αντικείμενο της κλάσης HRImpl, η οποία υλοποιεί τη διεπαφή HRInterface.
            HRInterface hr = new HRImpl();
            // Καλούμε τη μέθοδο rebind της κλάσης Naming για να καθορίσουμε την αναφορά (reference)
            // του αντικειμένου hr στη διεύθυνση rmi://localhost:1099/HRService.
            Naming.rebind("rmi://localhost:1099/HRService", hr);
        // Αν προκύψει κάποιο σφάλμα κατά την εκτέλεση, τότε εκτυπώνουμε το σχετικό μήνυμα.
        }catch(Exception e){
            System.out.println("Exception on Server "+e.getMessage());
        }
    }
     // Η main μέθοδος της κλάσης HRServer, η οποία ξεκινά τον RMI server.
    public static void main(String args[]){
        new HRServer();
    }
}
