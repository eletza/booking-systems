import java.rmi.server.*;
import java.rmi.*;
import java.util.Scanner;
// Η κλάση HRClientImpl υλοποιεί την διεπαφή HRClientInterface και επεκτείνει την UnicastRemoteObject
public class HRClientImpl extends UnicastRemoteObject implements HRClientInterface{
    // Κατασκευαστής της κλάσης που καλεί τον κατασκευαστή της υπερκλάσης UnicastRemoteObject
    public HRClientImpl() throws RemoteException{
        super();
    }
    // Αυτή η μέθοδος καλείται απομακρυσμένα για να ειδοποιήσει τον πελάτη και να λάβει την απάντησή του
    public String notifyMe(String msg) throws RemoteException{
         // Εμφανίζει το μήνυμα ειδοποίησης στον χρήστη
        System.out.println(msg);
        // Δημιουργία αντικειμένου Scanner για να διαβάσει την απάντηση του χρήστη
        Scanner sc = new Scanner(System.in);
         // Ανάγνωση της απάντησης από τον χρήστη
        String ans = sc.next();
         // Επιστροφή της απάντησης του χρήστη
        return ans;
    }
}
