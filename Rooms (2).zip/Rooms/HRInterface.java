import java.rmi.RemoteException;

// Η διεπαφή HRInterface περιγράφει τις λειτουργίες που μπορεί να προσφέρει ένα σύστημα διαχείρισης δωματίων ξενοδοχείου.
public interface HRInterface extends java.rmi.Remote{
  // Μέθοδος που επιστρέφει τη λίστα των δωματίων και των τιμών τους.
    public String list()
            throws java.rmi.RemoteException;
     // Μέθοδος για κράτηση δωματίων.Επιστρέφει:Την συνολική τιμή της κράτησης ή κατάλληλο μήνυμα λάθους.
    public int book(char type, int number, String name)
            throws java.rmi.RemoteException;
    // Μέθοδος που επιστρέφει τις κρατήσεις των πελατών.Επιστρέφει ένα string που περιέχει λεπτομέρειες για κάθε κράτηση.
    public String guests()
            throws java.rmi.RemoteException;
     // Μέθοδος για ακύρωση κράτησης δωματίων.Επιστρέφει:Μήνυμα επιτυχίας ή αντίστοιχο μήνυμα λάθους.
    public String cancel(char type, int number, String name)
            throws java.rmi.RemoteException;
     // Μέθοδος για εγγραφή πελάτη για ειδοποιήσεις (callback).Επιστρέφει:Τίποτα (void)
    public void registerForCallback(HRClientInterface obj, char type, int number, String name)
            throws java.rmi.RemoteException;
}
