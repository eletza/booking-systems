import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
// Η κλάση HRImpl υλοποιεί τη διεπαφή HRInterface και επεκτείνει την UnicastRemoteObject
public class HRImpl extends java.rmi.server.UnicastRemoteObject implements HRInterface{
    //Δήλωση μεταβλητών
    //πίνακας ακεραίων αποθηκεύει τον αριθμό των διαθέσιμων δωματίων για κάθε κατηγορία.
    private int[] rooms;
     //Αυτός ο πίνακας ακεραίων αποθηκεύει τις τιμές ανά διανυκτέρευση για κάθε κατηγορία δωματίων.
    private int[] price;
    //Αυτή η λίστα αποθηκεύει αντικείμενα τύπου Customer, που αντιπροσωπεύουν πελάτες που έχουν εγγραφεί για callbackειδοποιήσεις.
    ArrayList<Customer> clients;
     // Κατασκευαστής της κλάσης που καλεί τον κατασκευαστή της υπερκλάσης UnicastRemoteObject
    public HRImpl() throws java.rmi.RemoteException{
        super();
        readFile();
        price = new int[5];
         // Ορισμός των τιμών για τις διάφορες κατηγορίες δωματίων
        price[0] = 75;
        price[1] = 110;
        price[2] = 120;
        price[3] = 150;
        price[4] = 200;
        System.out.println("Server Running");
        //Αρχικοποιείται λίστα clients, η οποία θα αποθηκεύει αντικείμενα τύπου Customer.
        //Η ArrayList είναι μια δυναμική δομή δεδομένων που αποθηκεύει έναν μεταβαλλόμενο αριθμό αντικειμένων.
        clients = new ArrayList<>();
    }
     // Μέθοδος για την ανάγνωση του αρχείου που περιέχει τις πληροφορίες των δωματίων
     private void readFile(){
         //Δημιουργεί έναν πίνακα ακεραίων με 5 θέσεις για την αποθήκευση των διαθέσιμων δωματίων
        rooms = new int[5];
        try{
            //Δημιουργεί έναν BufferedReader για την ανάγνωση του αρχείου rooms.txt.
            BufferedReader br = new BufferedReader(new FileReader(new File("/home/eleftheria/Desktop/Rooms/rooms.txt")));
            //Διαβάζει πέντε γραμμές από το αρχείο και αποθηκεύει τους αριθμούς στον πίνακα rooms.
            for(int i=0;i<5;i++)
                rooms[i] = Integer.parseInt(br.readLine());
            //Κλείνει τον BufferedReader για να απελευθερώσει τους πόρους.
            br.close();
       // διαχειρίζονται εξαιρέσεις που μπορεί να προκύψουν κατά την ανάγνωση του αρχείου.
        }catch(FileNotFoundException e){
            System.out.println("Exception in HRImpl: "+e.getMessage());
        }catch(IOException e){
            System.out.println("Exception in HRImpl: "+e.getMessage());
        }
    }
     // Μέθοδος για την ενημέρωση του αρχείου δωματίων με τις τρέχουσες τιμές
     private void updateRoomFile(){
        try{
            // Δημιουργεί έναν BufferedWriter για την εγγραφή στο αρχείο rooms.txt.
            BufferedWriter bw = new BufferedWriter(new FileWriter("/home/eleftheria/Desktop/Rooms/rooms.txt"));
             //Εγγράφει τις τιμές του πίνακα rooms στο αρχείο rooms.txt.
            for(int i=0;i<5;i++)
                bw.write(rooms[i]+"\n");
            //Κλείνει τον BufferedWriter για να απελευθερώσει τους πόρους.
            bw.close();
        // Διαχειρίζεται εξαιρέσεις που μπορεί να προκύψουν κατά την εγγραφή στο αρχείο
        }catch(IOException e){
            System.out.println("Exception in HRImpl updateRoomFile: "+e.getMessage());
        }
    }
    // μέθοδος αποθηκεύει μια κράτηση σε ένα αρχείο, ενημερώνοντας το αρχείο reservations.txt με τις νέες πληροφορίες.
    private void saveReservation(char type, int number, String name, int total_price)   {
        try{
            //Δημιουργεί ένα αντικείμενο File,το αρχείο reservations.txt
            File res = new File("/home/eleftheria/Desktop/Rooms/reservations.txt");
            //Δημιουργεί ένα αντικείμενο File ,ένα προσωρινό αρχείο reservations_tmp.txt
            File tmp = new File("/home/eleftheria/Desktop/Rooms/reservations_tmp.txt");
            //Δημιουργεί ένα αντικείμενο Scanner για την ανάγνωση του αρχείου reservations.txt
            Scanner sc = new Scanner(res);
            //Δημιουργεί αντικείμενο PrintWriter για την εγγραφή στο προσωρινό αρχείο reservations_tmp.txt
            PrintWriter pw = new PrintWriter (new BufferedWriter(new FileWriter(tmp)));
            //t_type: Ο τύπος του δωματίου.
            String t_type = null;
            //n_name: Το όνομα του πελάτη.
            String n_name;
            //σημαία που δείχνει αν η εγγραφή του πελάτη ενημερώθηκε.
            boolean done = false;
            //resvs: Ο αριθμός των κρατήσεων.
            //cost: Το συνολικό κόστος της κράτησης.
            int resvs, cost;
            // Βρόχος για κάθε γραμμή του αρχείου reservations.txt.
            while(sc.hasNext()){
                n_name = sc.next();
                t_type = sc.next();
                resvs = sc.nextInt();
                cost = sc.nextInt();
                 //Ελέγχει αν το τρέχον όνομα και τύπος δωματίου από το αρχείο ταιριάζουν με αυτά της νέας κράτησης
                if(n_name.equals(name) && t_type.equals(Character.toString(type))){
                        done = true;
                        //Αν ταιριάζουν, ενημερώνει την υπάρχουσα εγγραφή με τον νέο αριθμό δωματίων και το συνολικό κόστος.
                        pw.println(name+" "+type+" "+ (resvs+number) +" "+(cost+total_price));   
                //Αν δεν ταιριάζουν, αντιγράφει την υπάρχουσα εγγραφή στο προσωρινό αρχείο.
                }else
                    pw.println(n_name+" "+t_type+" "+resvs+ " "+cost+" ");
            }
            //Αν δεν βρέθηκε εγγραφή για τον πελάτη, προσθέτει νέα εγγραφή στο προσωρινό αρχείο.
            if(!done)
                pw.println(name+" "+type+" "+number+ " "+total_price);
            //Διαγράφει το παλιό αρχείο reservations.txt και μετονομάζει το προσωρινό αρχείο reservations_tmp.txt σε reservations.txt
            res.delete();
            tmp.renameTo(res);
            // Κλείνει τον PrintWriter για να απελευθερώσει τους πόρους.
            pw.close();
        //διαχειρίζεται εξαιρέσεις που μπορεί να προκύψουν κατά την εγγραφή στο αρχείο.
        }catch(IOException e){
            System.out.println("Exception in HRImpl saveReservation: "+e.getMessage());
        }        
    }
     // Μέθοδος που επιστρέφει τη λίστα των δωματίων και των τιμών τους
    public String list() throws java.rmi.RemoteException{
    // Δημιουργούμε ένα αντικείμενο StringBuilder για τη δημιουργία του μηνύματος
        String msg = (new StringBuilder())
                      // Προσθέτουμε στο StringBuilder τον αριθμό των δωματίων κάθε τύπου με την τιμή τους
                    .append(rooms[0]).append(" Rooms of Type A - Price: 75€ per night\n")
                    .append(rooms[1]).append(" Rooms of Type B - Price: 110€ per night\n")
                    .append(rooms[2]).append(" Rooms of Type C - Price: 120€ per night\n")
                    .append(rooms[3]).append(" Rooms of Type D - Price: 150€ per night\n")
                    .append(rooms[4]).append(" Rooms of Type E - Price: 200€ per night\n")
                     // Μετατρέπουμε το StringBuilder σε String
                    .toString();
        // Επιστρέφουμε το String που περιέχει τη λίστα των δωματίων και των τιμών τους
        return msg;
     }
       // Μέθοδος για την κράτηση δωματίων
      public int book(char type, int number, String name) throws java.rmi.RemoteException{
        int available = rooms[type-65];// Μετατροπή του χαρακτήρα σε αριθμό
        int total_price;
         // Έλεγχος για έγκυρο τύπο δωματίου
        if((type < 65) || (type > 69))
            return -1;// Αν ο τύπος δωματίου δεν είναι έγκυρος, επιστρέφει -1
        // Έλεγχος αν δεν υπάρχουν διαθέσιμα δωμάτια
        if(available == 0 )
            return -2;// Αν δεν υπάρχουν διαθέσιμα δωμάτια, επιστρέφει -2
         // Έλεγχος αν διαθέσιμα δωμάτια είναι λιγότερα από τον αριθμό που ζητήθηκε
        else if((available < number) && (available > 0))
            return available; // Αν είναι λιγότερα, επιστρέφει τον αριθμό των διαθέσιμων δωματίων
        else{
             // Αφαίρεση του αριθμού των δωματίων από τη διαθεσιμότητα
            rooms[type-65] -= number;
             // Αποθήκευση των αλλαγών στο αρχείο των δωματίων
            updateRoomFile();
             // Υπολογισμός συνολικής τιμής της κράτησης
            total_price = number * price[type-65];
        // Αποθήκευση της κράτησης στο αρχείο των κρατήσεων
            saveReservation(type,number,name,total_price);
             // Επιστροφή του συνολικού ποσού της κράτησης
            return total_price;
        }
    }
     // Μέθοδος που επιστρέφει τις κρατήσεις των πελατών
    public String guests() throws java.rmi.RemoteException{
        String msg = new String();// Δημιουργία αλφαριθμητικού για το μήνυμα επιστροφής
         // Δημιουργία ενός Scanner για ανάγνωση από το αρχείο κρατήσεων
        try{
            Scanner sc = new Scanner(new File("/home/eleftheria/Desktop/Rooms/reservations.txt"));
            // Διάβασμα και δημιουργία μηνύματος για κάθε εγγραφή στο αρχείο
            while(sc.hasNext()){
                msg += "Client:" + sc.next();   // Προσθήκη ονόματος πελάτη
                msg += " Room_Type:" + sc.next(); // Προσθήκη τύπου δωματίου
                msg += " Reservations:" + sc.nextInt(); // Προσθήκη αριθμού κρατήσεων
                msg += " Total:" + sc.nextInt() + "€\n"; // Προσθήκη συνολικού ποσού σε ευρώ
            }
            // Κλείσιμο του Scanner μετά την ολοκλήρωση ανάγνωσης
            sc.close();
        }catch(FileNotFoundException e){
                // Εκτύπωση μηνύματος λάθους εάν το αρχείο δεν βρεθεί
                System.out.println("Exception in guests() "+e.getMessage());
        }
        return msg;
    }
    public String cancel(char type, int number, String name) throws java.rmi.RemoteException{
        // Αρχικοποίηση μηνύματος ακύρωσης
        String msg = null;
       // Αρχικοποίηση μηνύματος με υπόλοιπες κρατήσεις
        String rest = null;
        // Σημαία που δείχνει αν βρέθηκε κράτηση για ακύρωση
        boolean flag = false;
        
        try{
            String n_name;
            String t_type;
            int cost;
            
            int resvs;
            Integer diff = null;
            // Τα ορίζουμε έτσι ώστε να διαγράψουμε το ένα και να μετονομάσουμε το άλλο στην συνέχεια
            // Δημιουργία αρχείων για την αντιγραφή και αλλαγή των κρατήσεων
            File res = new File("/home/eleftheria/Desktop/Rooms/reservations.txt");
            File tmp = new File("/home/eleftheria/Desktop/Rooms/reservations_tmp.txt");
             // Δημιουργία Scanner για ανάγνωση από το αρχείο κρατήσεων
            Scanner sc = new Scanner(res);
             // Δημιουργία PrintWriter για εγγραφή στο αρχείο κρατήσεων tmp
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(tmp)));

            // Αντιγραφή απο reservations σε tmp_reservations και επεξεργασία πληροφοριών 
            while(sc.hasNext()){
                n_name = sc.next();
                t_type = sc.next();
                resvs = sc.nextInt();
                cost = sc.nextInt();
                
               // Εάν βρεθεί κράτηση για ακύρωση με το ίδιο όνομα και τύπο
                if(n_name.equals(name) && t_type.equals(Character.toString(type))){
                    flag = true;// Ορισμός της σημαίας ότι βρέθηκε κράτηση
                    diff = resvs - number; // Υπολογισμός νέου αριθμού κρατήσεων
                     // Εάν ο νέος αριθμός κρατήσεων είναι αρνητικός, επιστροφή σφάλματος
                    if(diff < 0)
                        return "Reservations are less than number specified";
                     
                    else if(diff > 0){
                        // Εγγραφή της κράτησης με το νέο αριθμό κρατήσεων και κόστος
                        pw.println(n_name+" "+t_type+" "+diff+" "+(diff*price[type-65]));
                        // Δημιουργία μηνύματος με τα υπόλοιπα δεδομένα κρατήσεων
                        rest = "Client:"+n_name+" Room_Type:"+t_type+" Reservations:"+diff+" Total_Amount "+(diff*price[type-65])+ "€\n";
                         // Αύξηση των διαθέσιμων δωματίων
                        rooms[type-65] += number;
                    }        
                }else{
                    // Αν δεν είναι κράτηση προς ακύρωση, γράψε την υπάρχουσα κράτηση στο tmp αρχείο
                    pw.println(n_name+" "+t_type+" "+resvs+" "+cost);
                    // Αν το όνομα ταιριάζει, προσθέστε την υπάρχουσα κράτηση στο υπόλοιπο
                    if(n_name.equals(name))
                        rest += "Client:"+n_name+" Room_Type:"+t_type+" Reservations:"+resvs+" Total_Amount "+cost+"€\n";                    
                }
            }
            
              // Κλείσιμο των αρχείων και ενημέρωση των δωματίων   
            res.delete();
            tmp.renameTo(res);
            pw.close();
            sc.close();
            updateRoomFile(); // Ενημέρωση του αρχείου δωματίων
            makeAvailable(type);// Κλήση μεθόδου για καθιστώντας διαθέσιμα τα δωμάτια
        }catch(IOException e){
            e.getMessage();// Εμφάνιση μηνύματος σφάλματος εάν προκύψει IOException
        }
        // Εάν δεν βρέθηκε κράτηση, επιστροφή μηνύματος
        if(!flag)
            msg = "Client has no reservations";
        // Αλλιώς επιστροφή του υπολοίπου κρατήσεων
        else
            msg = "Remaining reservations:\n"+rest;
         // Επιστροφή του τελικού μηνύματος 
        return msg;
    }
     // Μέθοδος για την εγγραφή πελάτη για callback ειδοποιήσεις
    public void registerForCallback(HRClientInterface obj, char type, int number, String name) throws java.rmi.RemoteException{
        // Αρχικοποίηση της μεταβλητής flag σε true
        boolean flag = true;
        // Έλεγχος αν ο πελάτης ήδη υπάρχει στη λίστα
        //Η μέθοδος ξεκινάει έναν βρόγχο for για να περάσει από όλους τους πελάτες που βρίσκονται στη λίστα clients
        //Σε κάθε επανάληψη του βρόγχου, ελέγχουμε αν το πελάτης στη θέση i έχει το ίδιο αντικείμενο HRClientInterface με το πελάτη obj που δόθηκε ως παράμετρος.
        for(int i=0;i<clients.size();i++)
            // Αν βρεθεί ο πελάτης στη λίστα, ορίζουμε το flag σε false
            if (clients.get(i).getClientInterface() == obj)
                flag = false;
        // Αν το flag είναι true, δηλαδή ο πελάτης δεν υπάρχει στη λίστα
        if(flag)
             // Προσθήκη νέου πελάτη στη λίστα clients
            clients.add(new Customer(obj,type,number,name));
    }
    
    private void unregister(HRClientInterface obj){
         // Αναζήτηση του πελάτη που έχει το συγκεκριμένο αντικείμενο HRClientInterface
        for(int i=0;i<clients.size();i++)
            // Αν βρεθεί ο πελάτης
            if (clients.get(i).getClientInterface() == obj)
                // Αφαίρεση του πελάτη από τη λίστα
                clients.remove(i);
    }
    //Μέθοδος που ελέγχει διαθέσιμα δωμάτια και ενημερώνει τους εγγεγραμένους πελάτες για την διαθεσιμότητα των δωματίων και τον τύπο τους
     void makeAvailable(char type) throws java.rmi.RemoteException{
        String opt;
        String tmpName;
        char tmpType;
        int tmpNumber;
        // ξεκινά μια επανάληψη μέσω όλων των πελατών που είναι αποθηκευμένοι στη λίστα clients.
        for(int i=0;i<clients.size();i++){
            // Για κάθε πελάτη,αποθηκεύονται όνομά του,ο τύπος δωματίου που ζήτησε και ο αριθμός των δωματίων που επιθυμεί να κλείσει.
            tmpName = clients.get(i).getName();
            tmpType = clients.get(i).getType();
            tmpNumber = clients.get(i).getNumber();
            // Αν ο τύπος του δωματίου που ζητά ο πελάτης είναι ίδιος με τον type που δόθηκε ως παράμετρος και αν ο αριθμός των δωματίων που ζητεί είναι μικρότερος ή ίσος με τα διαθέσιμα δωμάτια (rooms[type - 65]), τότε συνεχίζουμε
            if((tmpType == type) && (tmpNumber <= rooms[type-65])){
             //Ο πελάτης ενημερώνεται για τη διαθεσιμότητα των δωματίων και του ζητείται να επιλέξει αν θέλει να τα κλείσει ή όχι.
                opt = clients.get(i).getClientInterface().notifyMe(tmpNumber+" rooms of type "+tmpType+" available\nBook them? (y/n)");
                //Αν ο πελάτης απαντήσει θετικά (Y ή y), τότε γίνεται κλήση της μεθόδου book για να κλείσει τα δωμάτια.
                if(opt.equals("Y") || opt.equals("y")){
                    book(type,tmpNumber,tmpName);// Κράτηση των δωματίων
                    //ο πελάτης αφαιρείται από τη λίστα clients με τη χρήση της μεθόδου unregister
                    unregister(clients.get(i).getClientInterface());
                    break;
                }
            }
        }
    }
}
    // Η κλάση Customer αντιπροσωπεύει έναν πελάτη που έχει κάνει κράτηση δωματίων.
    class Customer{
    // Το αντικείμενο του πελάτη που υλοποιεί το HRClientInterface
    private HRClientInterface obj;
     // Ο τύπος του δωματίου που έχει κλείσει ο πελάτης
    private char type;
    // Ο αριθμός των δωματίων που έχει κλείσει ο πελάτης
    private int number;
     // Το όνομα του πελάτη
    private String name;
     // Κατασκευαστής της κλάσης Customer
    public Customer(HRClientInterface obj,char type,int number,String name){
        this.type = type; // Αρχικοποίηση του τύπου δωματίου
        this.number = number;// Αρχικοποίηση του αριθμού των δωματίων
        this.obj = obj;// Αρχικοποίηση του αντικειμένου πελάτη που υποστηρίζει το RMI interface
        this.name = name; // Αρχικοποίηση του ονόματος του πελάτη
    }
        // Μέθοδος που επιστρέφει τον τύπο του δωματίου
    public char getType(){
        return type;
    }
      // Μέθοδος που επιστρέφει τον αριθμό των δωματίων
    public int getNumber(){
        return number;
    }
      // Μέθοδος που επιστρέφει το όνομα του πελάτη
    public String getName(){
        return name;
    }
    // Μέθοδος που επιστρέφει το αντικείμενο του πελάτη που υλοποιεί το HRClientInterface
    public HRClientInterface getClientInterface(){
        return obj;
    }
}
