import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Scanner;

public class HRClient {
    public static void main(String args[]){
        try{
            String msg;
            // Αναζήτηση του απομακρυσμένου αντικειμένου με χρήση του RMI registry
            HRInterface hr = (HRInterface) Naming.lookup("rmi://localhost:1099/HRService");
            // Με βάση τον αριθμό που δόθηκαν 
            switch (args.length){
                //αν δόθηκε ένα όρισμα
                case 1:
                    if(args[0].equals("list")){
                        // Λίστα όλων των κατηγοριών δωματίων και της διαθεσιμότητάς τους
                        msg = hr.list();
                        System.out.println(msg);
                    }
                    if(args[0].equals("guests")){
                        // Λίστα όλων των τρεχουσών κρατήσεων
                        msg = hr.guests();
                        if(msg.isEmpty())
                            System.out.println("No current reservations");
                        else
                        System.out.println(msg);
                    }
                    break;
                // Αν δόθηκαν 4 ορίσματα
                case 4:
                    if(args[0].equals("book")){
                        // Κράτηση δωματίων
                        int out = hr.book(args[1].charAt(0), Integer.parseInt(args[2]), args[3]);
                        if((out > 0) && (out < 60)){
                             // Αν υπάρχουν δωμάτια αλλά δεν έχουν κρατηθεί 
                            System.out.println("There are "+out+" rooms available");
                            System.out.println("Would you like to book them? (y/n)");
                            Scanner sc = new Scanner(System.in);
                            sc.reset();
                            if(sc.next().equals("y") || sc.next().equals("Y"))
                                 // Κράτηση των δωματίων ξανά
                                out = hr.book(args[1].charAt(0), out, args[3]);
                            sc.close();
                        }
                         // Επιτυχής κράτηση
                        if(out >= 60)
                            System.out.println("Reservation success. Total amount: "+out+"€");
                        // Δεν υπάρχουν διαθέσιμα δωμάτια
                        else if(out == -2){
                            System.out.println("No rooms of this category available");
                            System.out.println("Would you like to subscribe to waiting list?(y/n)");
                            Scanner sc = new Scanner(System.in);
                            String opt = sc.next();
                            // Εγγραφή για ειδοποίηση εάν ο χρήστης επιλέξει τη λίστα αναμονής
                            if(opt.equals("y") || opt.equals("Y")){
                                HRClientInterface ci = new HRClientImpl();
                                hr.registerForCallback(ci, args[1].charAt(0), Integer.parseInt(args[2]), args[3]);
                                System.out.println("Waiting for availability");
                            }
                        }
                        // Άκυρη επιλογή δωματίου
                        else
                            System.out.println("Not a valid room choice");
                    }
                     // Ακύρωση κράτησης
                    if(args[0].equals("cancel")){
                        msg = hr.cancel(args[1].charAt(0), Integer.parseInt(args[2]), args[3]);
                        System.out.println(msg);
                    }
                    break;
                   // Όταν το μήκος των ορισμάτων δεν είναι 4 ,ούτε 1
                default:
                    System.out.println("Run Error. Available options are:");
                    System.out.println("java HRClient list");
                    System.out.println("java HRClient book <type> <number> <name>");
                    System.out.println("java HRClient guests");
                    System.out.println("java HRClient cancel <type> <number> <name>");
                    System.out.println("Hostname: rmi://localhost/HRService");
                    break;
            }  
        //διάφορες εξαιρέσεις που μπορεί να συμβούν κατά την εκτέλεση 
        }catch(NumberFormatException | MalformedURLException | NotBoundException | RemoteException e){
            e.printStackTrace();
        }
    }
}
