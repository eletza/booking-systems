// Δημόσια διεπαφή HRClientInterface που επεκτείνει τη java.rmi.Remote
public interface HRClientInterface extends java.rmi.Remote{
   // Δημόσια μέθοδος notifyMe που λαμβάνει ένα μήνυμα και επιστρέφει μια συμβολοσειρά
    // Μπορεί να πετάξει μια εξαίρεση java.rmi.RemoteException
    public String notifyMe(String message)
            throws java.rmi.RemoteException;
}
